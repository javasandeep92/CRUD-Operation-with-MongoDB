package com.sample.project.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.sample.project.entity.Book;

public interface BookRepository extends MongoRepository<Book, Integer> {

}
