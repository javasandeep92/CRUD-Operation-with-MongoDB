package com.sample.project.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.sample.project.repository.BookRepository;

public class BookService {
	
	
	
	
	@Autowired
	private BookRepository repository;
	
	
	

}
